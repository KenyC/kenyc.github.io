# Features to be added

2. Movement arrows
5. Make an exe version of it
6. Transducer for forest
